// Carrega os dados gravados no navegador ou define os valores iniciais de fábrica
let dinheiro = Number(localStorage.getItem("dinheiro")) || 0;
let multiplicador = Number(localStorage.getItem("multiplicador")) || 1;
let dinheiroPorClick = Number(localStorage.getItem("dinheiroPorClick")) || 1;
let custoUpgrade = Number(localStorage.getItem("custoUpgrade")) || 100;

// Atualiza o ecrã imediatamente assim que qualquer uma das duas páginas abre
atualizarDisplay();

function clicar() {
    dinheiro += dinheiroPorClick;
    gravarProgresso();
    atualizarDisplay();
}

function comprar() {
    if (dinheiro >= custoUpgrade) {
        dinheiro -= custoUpgrade;
        multiplicador += 1;
        dinheiroPorClick = (1 * multiplicador);
        custoUpgrade *= 2; // Duplica o preço para o próximo nível
        
        gravarProgresso();
        atualizarDisplay();
    } else {
        alert("Dinheiro insuficiente para comprar este item!");
    }
}

function gravarProgresso() {
    localStorage.setItem("dinheiro", dinheiro);
    localStorage.setItem("multiplicador", multiplicador);
    localStorage.setItem("dinheiroPorClick", dinheiroPorClick);
    localStorage.setItem("custoUpgrade", custoUpgrade);
}

// Versão corrigida e protegida contra o erro 'TypeError of null'
function atualizarDisplay() {
    const elDinheiro = document.getElementById("dinheiro");
    const elMultiplicador = document.getElementById("multiplicador");
    const elCusto = document.getElementById("custoUpgrade");

    // As condições 'if' abaixo evitam que o código trave se o ID não existir na página atual
    if (elDinheiro) {
        elDinheiro.innerText = `${dinheiro}$`;
    }
    if (elMultiplicador) {
        elMultiplicador.innerText = `x${multiplicador}`;
    }
    if (elCusto) {
        elCusto.innerText = `Custo do Upgrade: ${custoUpgrade}$`;
    }
}
